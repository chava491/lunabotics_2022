"""
This is the official main file

@created: 10-25-2020
"""

from locomotion import Locomotion
from digging import Digging
from dumping import Dumping

class Robot:

    def __init__(self):
        self.state = "manual"

    def get_state(self):
        return state

    def set_state(self, state):
        self.state = state
